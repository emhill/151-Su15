import java.awt.Graphics;


public class BoxCar {
	private BoxCarPart bcp1, bcp2, bcp3;
	
	public BoxCar(int x, int y, int width, int height) {
		bcp1 = new BoxCarPart(x, 				y, width / 3, height);
		bcp2 = new BoxCarPart(x + width / 3, 	y, width / 3, height);
		bcp3 = new BoxCarPart(x + 2 * width / 3,	y, width / 3, height);
	}
	
	public void draw(Graphics page) {
		bcp1.draw(page);
		bcp2.draw(page);
		bcp3.draw(page);
	}

}
