import java.awt.Color;
import java.awt.Graphics;


public class Square {
	private int x, y, width;
	private Color fillColor, outlineColor;
	
	public Square(int x, int y, int s, Color f, Color o) {
		this.x = x;
		this.y = y;
		width = s;
		fillColor = f;
		outlineColor = o;
	}
	
	public Square(int x, int y, int s, Color f) {
		this(x, y, s, f, f);
	}
	
	public Square() {
		this(50, 50, 100, Color.BLUE);
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int size) {
		this.width = size;
	}

	public Color getFillColor() {
		return fillColor;
	}

	public void setFillColor(Color fillColor) {
		this.fillColor = fillColor;
	}

	public Color getOutlineColor() {
		return outlineColor;
	}

	public void setOutlineColor(Color outlineColor) {
		this.outlineColor = outlineColor;
	}
	
	public int getArea() {
		return width * width;
	}
	
	public int getPerimeter() {
		return 4 * width;
	}
	
	public void draw(Graphics page) {
		page.setColor(fillColor);
		page.fillRect(x, y, width, width);
		page.setColor(outlineColor);
		page.drawRect(x, y, width, width);
	}

	public static void main(String[] args) {
		Square s = new Square();
		System.out.println("Area: " + s.getArea());
		System.out.println("Perimeter: " + s.getPerimeter()); 

	}

}
