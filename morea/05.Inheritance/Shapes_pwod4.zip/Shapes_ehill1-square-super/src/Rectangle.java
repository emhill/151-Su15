import java.awt.Color;
import java.awt.Graphics;


public class Rectangle extends Square {
	private int height;
	
	public Rectangle(int x, int y, int w, int h, Color f, Color o) {
		super(x, y, w, f, o);
		height = h;
	}
	
	public Rectangle(int x, int y, int w, int h, Color f) {
		this(x, y, w, h, f, f);
	}
	
	public Rectangle() {
		this(50, 50, 100, 50, Color.BLUE);
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
	
	public int getArea() {
		return getWidth() * height;
	}
	
	public int getPerimeter() {
		return 2 * getWidth() + 2 * height;
	}
	
	public void draw(Graphics page) {
		page.setColor(getFillColor());
		page.fillRect(getX(), getY(), getWidth(), height);
		page.setColor(getOutlineColor());
		page.drawRect(getX(), getY(), getWidth(), height);
	}

	public static void main(String[] args) {
		Rectangle s = new Rectangle();
		System.out.println("Area: " + s.getArea());
		System.out.println("Perimeter: " + s.getPerimeter()); 

	}
}
