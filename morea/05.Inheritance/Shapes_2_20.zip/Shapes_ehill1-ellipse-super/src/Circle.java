import java.awt.Color;


public class Circle extends Ellipse {

	public Circle() {
		this(100, 100, 50, Color.BLUE);
	}

	public Circle(int x, int y, int rw, Color c) {
		this(x, y, rw, c, c);
	}

	public Circle(int x, int y, int rw, Color c, Color o) {
		super(x, y, rw, rw, c, o);
	}
	
	public int getRadius() {
		return super.getWidthRadius();
	}
	
	public void setRadius(int r) {
		super.setWidthRadius(r);
		super.setHeightRadius(r);
	}
	
	public double getPerimeter() {
		return 2 * Math.PI * getRadius();
	}

	public static void main(String[] args) {
		Circle c = new Circle(50, 50, 100, Color.MAGENTA);
		//c.setRadius(25);
		System.out.println("The radius is: " + c.getRadius());
		System.out.println("The area is: " + c.getArea());
		System.out.println("The perimeter is: " + c.getPerimeter());

	}

}
