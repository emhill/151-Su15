
public class Event {
	private DayOfWeek day;
	private String description;

	public Event(DayOfWeek d, String ds) {
		description = ds;
		day = d;
	}
	
	public Event(String day, String ds) {
		description = ds;
		this.day = DayOfWeek.getDay(day);
	}
	
	public String toString() {
		return day.toString() + ": " + description;
	}

	public DayOfWeek getDayOfWeek() {
		return day;
	}
	
	public String getDescription() {
		return description;
	}
}
