
public enum DayOfWeek {
	mon("Monday"), 
	tues("Tuesday"), 
	wed("Wednesday"), 
	thurs("Thursday"), 
	fri("Friday"), 
	sat("Saturday"), 
	sun("Sunday");
	
	private String nameString;
	
	private DayOfWeek(String n) {
		nameString = n;
	}
	
	public String toString() {
		return nameString;
	}
	
	// *sigh* can't override valueOf
	public static DayOfWeek getDay(String d) {
		for (DayOfWeek day : DayOfWeek.values())
			if (
					d.toLowerCase().equals(day.name()) ||
					d.toLowerCase().equals(day.toString().toLowerCase())
				)
				return day;
		//return DayOfWeek.valueOf(d); // error on "Monday"
		System.err.println("\"" + d + "\" is not a recognized day. " +
							"Sunday substituted instead.");
		return sun; // for error handling
	}
}
