import java.util.ArrayList;


public class Calendar {

	public ArrayList<Event> events = new ArrayList<Event>();
	
	public void addEvent(Event e) {
		events.add(e);
	}
	
	public void print() {
		System.out.println("------- EVENTS -------");
		for (DayOfWeek day : DayOfWeek.values()) {
			System.out.println(day);
			for (Event e : events) {
				if (e.getDayOfWeek() == day)
					System.out.println("\t" + e.getDescription());
			}
		}
	}
	
	public static void main(String[] args) {
		Calendar cal = new Calendar();
		cal.addEvent(new Event("mon", "WOD4"));
		cal.addEvent(new Event(DayOfWeek.mon, "No 117"));
		cal.addEvent(new Event(DayOfWeek.tues, "WOD5"));
		cal.addEvent(new Event("Monday", "WOD4b"));
		cal.addEvent(new Event("Mon", "WOD5"));
		cal.addEvent(new Event("WED", "WOD9"));
		cal.addEvent(new Event("MONDAY", "WOD7"));
		cal.addEvent(new Event("EASTER", "WOD8"));
		cal.print();
	}

}
