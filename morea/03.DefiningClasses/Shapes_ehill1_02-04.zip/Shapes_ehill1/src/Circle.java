import java.awt.Color;
import java.awt.Graphics;


public class Circle {

	private int x;
	private int y;
	private int radius;
	private Color fillColor;
	
	public Circle() {
		x = 250;
		y = 250;
		radius = 50;
		fillColor = Color.BLUE;
	}
	
	public Circle(int x, int y, int r, Color c) {
		this.x = x;
		this.y = y;
		radius = r;
		fillColor = c;
	}
	
	public void draw(Graphics page) {
		page.setColor(fillColor);
		page.fillOval(x-radius, y-radius, 2 * radius, 2 * radius);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
