import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;


public class Triangle {

	private int x, y, width, height;
	private Color fillColor, outlineColor;
	
	public Triangle() {
		this(100, 100, 50, 100, Color.RED);
	}
	
	public Triangle(int x, int y, int w, int h, Color f, Color o) {
		this.x = x;
		this.y = y;
		width = w;
		height = h;
		fillColor = f;
		outlineColor = o;
	}
	
	public Triangle(int x, int y, int w, int h, Color f) {
		this(x, y, w, h, f, Color.DARK_GRAY);
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public Color getFillColor() {
		return fillColor;
	}

	public void setFillColor(Color fillColor) {
		this.fillColor = fillColor;
	}
	
	public void setColor(Color fillColor) {
		this.fillColor = fillColor;
		this.outlineColor = fillColor;
	}

	public Color getOutlineColor() {
		return outlineColor;
	}

	public void setOutlineColor(Color outlineColor) {
		this.outlineColor = outlineColor;
	}
	
	public double getArea() {
		return width * height * 0.5;
	}
	
	public void draw(Graphics page) {
		page.setColor(fillColor);
		Polygon p = new Polygon();
		p.addPoint(x, y);
		p.addPoint(x + width / 2, y + height);
		p.addPoint(x - width / 2, y + height);
		page.fillPolygon(p);
		page.setColor(outlineColor);
		page.drawPolygon(p);
	}

	public static void main(String[] args) {
		Triangle t = new Triangle();
		System.out.println("Area: " + t.getArea());
	}

}
