import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;


public class Forest {
	
	private ArrayList<Tree> trees = new ArrayList<Tree>();
	
	public Forest(int x, int y, int width, int height) {
		Tree tree1 = new Tree(x + 3 * width / 8, y, width / 2, height);
		Tree tree2 = new Tree(x + 5 * width / 16, y + height / 4,
							  width / 4, 3 * height / 8,
							  Color.GREEN.darker().darker().darker(), 
							  Color.YELLOW.darker());
		Tree tree3 = new Tree(x + 2 * width / 3, y + 3 * height / 16,
				  width / 3, 11 * height / 16,
				  Color.GREEN.darker().darker(), 
				  Color.ORANGE.darker().darker());
		trees.add(tree2);
		trees.add(tree3);
		trees.add(tree1);
	}
	
	public void draw(Graphics page) {
		for (Tree t : trees)
			t.draw(page);
	}
}
