import java.awt.Color;
import java.awt.Graphics;


public class Tree {
	private Triangle top;
	private Rectangle trunk;
	
	public Tree() {
		this(200, 200, 100, 200);
	}
	
	public Tree(int x, int y, int width, int height) {
		this(x, y, width, height, 
				Color.GREEN, Color.ORANGE.darker());
	}
	
	public Tree(int x, int y, int width, int height, 
			Color topColor, Color trunkColor) {
		top = new Triangle();
		trunk = new Rectangle();
		setBounds(x, y, width, height);
		top.setColor(topColor);
		trunk.setColor(trunkColor);
	}

	public void setBounds(int x, int y, int width, int height) {
//		    The tree starts at x, y and extends to width & height
//		    The trunk is 1/4 height of the tree & 1/5 the width
//		    The top is 3/4 height of the tree & the full width

		top.setWidth(width);
		top.setHeight((int) (.75 * height));
		top.setX(x + width / 2);
		top.setY(y);
		
		trunk.setWidth(width / 5);
		trunk.setHeight(height / 4);
		trunk.setX(x + 4 * width / 10);
		trunk.setY(y + top.getHeight());
	}
	
	public void draw(Graphics page) {
		trunk.draw(page);
		top.draw(page);
	}

	public Color getTopColor() {
		return top.getFillColor();
	}
	
	public Color getTrunkColor() {
		return trunk.getFillColor();
	}
	
	public void setTopColor(Color c) {
		top.setColor(c);
	}
	
	public void setTrunkColor(Color c) {
		trunk.setColor(c);
	}
	
}
