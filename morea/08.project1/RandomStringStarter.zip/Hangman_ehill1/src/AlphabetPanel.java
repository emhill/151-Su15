import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class AlphabetPanel extends JPanel {
	
	private static final int WIDTH = 650;
	private static final int HEIGHT = 50;
	
	public AlphabetPanel() {
		// Add the letters to the panel
		for (char x = 'A'; x <= 'Z'; x++) {
			//System.out.println(x);
			Text t = new Text(Character.toString(x));
			t.hideUnderline();
			t.setLetterColor(Color.GRAY);
			//t.setVisible(true);
			super.add(t);
		}
		
		System.out.println(this.getLetterColor('*'));
	}
	
	// a method that gets the color of a specified letter. 
	// If the letter is not valid (i.e., not in the panel), 
	// return null.
	public Color getLetterColor(char c) {
		Color color = null;
		if (c >= 'A' && c <= 'Z')
			color = ((Text)super.getComponent(c - 'A')).getLetterColor();
		return color;
	}
	
//	public void paintComponent(Graphics page) {
//		super.paintComponent(page);
//	}
	
	// a method that resets the alphabet panel letters all to black
	public void reset() {
		// TODO
		repaint();
	}
	
	/* when a consonant is pressed that letter should turn red, 
	 * a vowel should change to green, the spacebar should reset 
	 * or clear the alphabet panel (all other keys should do 
	 * nothing).  
	 */
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Hangman AlphabetPanel");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		JPanel panel = new AlphabetPanel();
		panel.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}


	
	
}
