import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Picture extends JPanel {
	
	private Circle circle;
	private Circle circle2;
	
	public Picture() {
		System.out.println("Picture Constructor");
		circle = new Circle();
		circle.setOutlineColor(Color.MAGENTA);
		circle2 = new Circle(100, 100, 100, Color.cyan, Color.PINK);
	}
	
	public void paintComponent(Graphics page) {
		System.out.println("Picture.paintComponent()");
		circle.draw(page);
		circle2.draw(page);
	}
	
	public static void main(String[] args)
	{
		System.out.println("Picture main");
		JFrame frame = new JFrame("Picture using Shapes");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		JPanel panel = new Picture();
		panel.setPreferredSize(new Dimension(500,500));
		
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}


	
	
}
