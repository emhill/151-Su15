import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Picture extends JPanel {
	
	private Circle circle;
	private Circle sun;

	
	public Picture() {
		circle = new Circle(300, 300, 100, Color.MAGENTA);
		sun = new Circle(100, 100, 50, Color.orange);
	}
	
	public void paintComponent(Graphics page) {
		circle.paint(page);
		sun.paint(page);
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Picture");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		JPanel panel = new Picture();
		panel.setPreferredSize(new Dimension(500,500));
		
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}
