public abstract class Item implements DoMEEntry {

	protected String title;
	protected int playingTime;
	protected boolean gotIt;
	protected String comment;

	public Item() {
		super();
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#setComment(java.lang.String)
	 */
	@Override
	public void setComment(String comment) {
	    this.comment = comment;
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#getComment()
	 */
	@Override
	public String getComment() {
	    return comment;
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#setOwn(boolean)
	 */
	@Override
	public void setOwn(boolean ownIt) {
	    gotIt = ownIt;
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#getOwn()
	 */
	@Override
	public boolean getOwn() {
	    return gotIt;
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#print()
	 */
	@Override
	public void print() {
	    printType();
		System.out.print(title + " (" + playingTime + " mins)");
	    if(gotIt) {
	        System.out.println("*");
	    }
	else {
	        System.out.println();
	    }
	    printSpecifics();
	    //System.out.println("    " + artist);
	    //System.out.println("    tracks: " + numberOfTracks);
	    System.out.println("    " + comment);
	}
	
	protected abstract void printSpecifics();
	protected abstract void printType();

}