/**
 * The CD class represents a CD object. Information about the 
 * CD is stored and can be retrieved.
 * 
 * @author Michael Kolling and David J. Barnes
 * @version 2008.03.30
 */
public class CD extends Item
{
    String artist;
    int numberOfTracks;
    /**
     * Initialize the CD.
     * @param theTitle The title of the CD.
     * @param theArtist The artist of the CD.
     * @param tracks The number of tracks on the CD.
     * @param time The playing time of the CD.
     */
    public CD(String theTitle, String theArtist, int tracks, int time)
    {
        title = theTitle;
        artist = theArtist;
        numberOfTracks = tracks;
        playingTime = time;
        gotIt = false;
        comment = "<no comment>";
    }
    
    @Override
	protected void printSpecifics() {
    	System.out.println("    " + artist);
		System.out.println("    tracks: " + numberOfTracks);
	}

	@Override
	protected void printType() {
		System.out.print("CD: ");
	}
}
