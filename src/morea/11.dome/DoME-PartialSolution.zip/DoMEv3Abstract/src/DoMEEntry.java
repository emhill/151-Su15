public interface DoMEEntry {

	/**
	 * Enter a comment for this CD.
	 * @param comment The comment to be entered.
	 */
	public void setComment(String comment);

	/**
	 * @return The comment for this CD.
	 */
	public String getComment();

	/**
	 * Set the flag indicating whether we own this CD.
	 * @param ownIt true if we own the CD, false otherwise.
	 */
	public void setOwn(boolean ownIt);

	/**
	 * @return true if we own a copy of this CD.
	 */
	public boolean getOwn();

	/**
	 * Print details about this CD to the text terminal.
	 */
	public void print();

}