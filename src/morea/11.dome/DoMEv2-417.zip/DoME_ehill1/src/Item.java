public class Item {

	protected String title;
	protected int playingTime;
	protected boolean gotIt;
	protected String comment;

	public Item(String theTitle, int time) {
		title = theTitle;
        playingTime = time;
        gotIt = false;
        comment = "<no comment>";
	}

	/**
	 * Enter a comment for this DVD.
	 * @param comment The comment to be entered.
	 */
	public void setComment(String comment) {
	    this.comment = comment;
	}

	/**
	 * @return The comment for this DVD.
	 */
	public String getComment() {
	    return comment;
	}

	/**
	 * Set the flag indicating whether we own this DVD.
	 * @param ownIt true if we own the DVD, false otherwise.
	 */
	public void setOwn(boolean ownIt) {
	    gotIt = ownIt;
	}

	/**
	 * @return true if we own a copy of this DVD.
	 */
	public boolean getOwn() {
	    return gotIt;
	}
	
    public void print()
    {
        System.out.print("Item: " + title + " (" + playingTime + " mins)");
        if(gotIt) {
            System.out.println("*");
        }
	else {
            System.out.println();
        }
        //System.out.println("    " + director);
        System.out.println("    " + comment);
    }

}