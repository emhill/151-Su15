import java.awt.Color;
import java.awt.Graphics;


public class Ellipse extends Circle {

	private int heightRadius;
	
	public Ellipse() {
		super();
		heightRadius = super.getRadius() * 2;
	}

	public Ellipse(int x, int y, int r, int h, Color c) {
		this(x, y, r, h, c, c);
	}

	public Ellipse(int x, int y, int r, int h, Color c, Color o) {
		super(x, y, r, c, o);
		heightRadius = h;
	}

	public int getHeightRadius() {
		return heightRadius;
	}

	public void setHeightRadius(int heightRadius) {
		this.heightRadius = heightRadius;
	}
	
	public void draw(Graphics page) {
		System.out.println("Ellipse.draw");
		page.setColor(fillColor);
		page.fillOval(x-radius, y-radius, 2 * radius, 2 * heightRadius);
		page.setColor(outlineColor);
		page.drawOval(x-radius, y-radius, 2 * radius, 2 * heightRadius);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
