
public class PiggyBank {

	// Add 4 fields to this class: pennies, nickels, dimes, and quarters. 
	// These fields will hold the number of each type of coin in your 
	// piggy bank.
	
	private int pennies, nickels, dimes, quarters;
	
	// Create a default constructor with no parameters that initializes the 
	// fields to an empty piggy bank.
	
	public PiggyBank() {
		pennies = 0;
		nickels = 0;
		dimes = 0;
		quarters = 0;
	}
	
	// Write 4 methods to insert a single coin of each type: insertPenny, 
	// insertNickel, insertDime, and insertQuarter. The method signatures 
	// are similar in that there is no return value and no parameters.
	
	public void insertPenny() {
		pennies += 1; // pennies = pennies + 1; pennies++;
	}
	
	public void insertNickel() {
		nickels++;
	}
	
	public void insertDime() {
		dimes += 1;
	}
	
	public void insertQuarter() {
		quarters = quarters + 1;
	}
	
	// Write 4 methods to insert multiple coins of each type: insertPennies,
	// insertNickels, insertDimes, and insertQuarters. The method 
	// signatures are similar in that there is no return value and one 
	// parameter.
	
	public void insertPennies(int numCoins) {
		pennies += numCoins;
	}
	
	public void insertNickels(int numCoins) {
		nickels += numCoins;
	}
	
	public void insertDimes(int numCoins) {
		dimes += numCoins;
	}
	
	public void insertQuarters(int numCoins) {
		quarters += numCoins;
	}
	
	public void print() {
		System.out.println("Number of quarters: " + quarters);
		System.out.println("Number of dimes: " 	  + dimes);
		System.out.println("Number of nickels: "  + nickels);
		System.out.println("Number of pennies: "  + pennies);
		System.out.println("--------------------");
		System.out.println("Total in cents: " + getAmount());
	}
	
	public int getAmount() {
		return quarters * 25 + dimes * 10 + nickels * 5 + pennies;
	}
	
	public void insertAmount(int cents) {
		insertQuarters(cents / 25);
		cents = cents % 25;
		
		insertDimes(cents / 10);
		cents = cents % 10;
		
		insertNickels(cents / 5);
		cents = cents % 5;
		
		insertPennies(cents);
	}
	
	public static void main(String[] args) {
		PiggyBank pb = new PiggyBank();
		pb.insertQuarters(2);
		pb.insertDime();
		pb.insertNickel();
		pb.insertPennies(2);
		pb.insertAmount(67);
		pb.print();
	}
}
