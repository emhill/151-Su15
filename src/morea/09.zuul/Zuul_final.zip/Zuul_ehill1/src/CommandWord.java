/**
 * This class is part of the "World of Zuul" application. 
 * "World of Zuul" is a very simple, text based adventure game.  
 * 
 * This class holds an enumeration of all command words known to the game.
 * It is used to recognise commands as they are typed in.
 *
 * @author  Michael Kolling and David J. Barnes
 * @version 2008.03.30
 */

public enum CommandWord
{
    // a constant array that holds all valid command words
//    private static final String[] validCommands = {
//        "go", "quit", "help", "look"
//    };
	
	go("allez"), quit("quit"), help("help"), look("look");
	
	private String equivalent;
    
    public static void showAll() {
    	for (CommandWord command : CommandWord.values())
    		System.out.print(command + " ");
    	System.out.println();
    }

    /**
     * Constructor - initialise the command words.
     */
    private CommandWord(String equiv)
    {
        this.equivalent = equiv;
    }

    /**
     * Check whether a given String is a valid command word. 
     * @return true if a given string is a valid command,
     * false if it isn't.
     */
    public static boolean isCommand(String aString)
    {
    	for (CommandWord command : CommandWord.values()) {
            if(command.toString().toLowerCase().equals(aString.toLowerCase()))
                return true;
        }
        // if we get here, the string was not found in the commands
        return false;
    }
    
    /**
     * getCommand: Return the string version of this CommandWord
     */
    public static String getCommand(CommandWord c) {
    	return c.toString();
    }

    /**
     * getCommandWord: Find the CommandWord associated with a command word.
     * @param commandWord The word to look up.
     * @return The CommandWord correspondng to commandWord, or UNKNOWN
     *         if it is not a valid command word.
     */
    public static CommandWord getCommandWord(String s) {
    	for (CommandWord command : CommandWord.values()) {
            if(command.toString().toLowerCase().equals(s.toLowerCase()))
                return command;
        }
    	return null;
    }

    /**
     * toString: Return the string version of this CommandWord
     */
    public String toString() {
    	return equivalent;
    }

}
