
public enum Direction {
	north, south, east, west, up, down;
	
	public static Direction getDirection(String dir){
		Direction d;
		switch (dir.toLowerCase()) {
			case "north": d = north; break;
			case "south": d = south; break;
			case "east": d = east; break;
			case "west": d = west; break;
			case "up": d = up; break;
			case "down": d = down; break;
			default: d = null;
		}
//		if (dir.toLowerCase().equals("north"))
//			d = north;
//		else if (dir.toLowerCase().equals("south"))
//			d = south;
//		// ...
//		else
//			d = null;
		return d;
	}
}
