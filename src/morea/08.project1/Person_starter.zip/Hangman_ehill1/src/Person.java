import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Person extends JPanel {
	
	
	private static final int WIDTH = 500;
	private static final int HEIGHT = 500;
	
	private static final int NUM_SHAPES = 6;
	
	private int numLeft = NUM_SHAPES;
	
	public Person() {
		this.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				// add code so if not all shown, the next body part
				// is shown, otherwise the person is reset
				
				// if not all body parts shown
					showNext();
				// otherwise
					// reset person
			}
		});

	}
	
	public void paintComponent(Graphics page) {
		super.paintComponent(page);
		
		// draw scaffold
		
		if (numLeft < 6) {
			page.draw3DRect(100, 100, 50, 200, true);
		}
		
		if (numLeft < 5)
			page.draw3DRect(50, 50, 50, 200, true);
		
		if (numLeft < 4)
			page.draw3DRect(150, 150, 50, 200, true);
	}
	
	// resets the number of turns left and erases the person so it is not visible 
	public void reset() {
		numLeft = NUM_SHAPES;
		repaint();
	}
	
	// progressively causes the next body part to be shown
	public void showNext() {
		numLeft--;
		repaint();
	}
	
	public int getNumLeft() {
		return numLeft;
	}
	
	/* It should display a person object and when you click on it the 
	 * next body part should show, if all parts are visible, then it 
	 * should be reset so it is no longer visible.  
	 */
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Hangman Person");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		JPanel panel = new Person();
		panel.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}


	
	
}
