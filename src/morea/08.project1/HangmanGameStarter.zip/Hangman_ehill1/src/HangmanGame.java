import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.BoxLayout;
import javax.swing.JFrame;



public class HangmanGame extends JFrame {

	private Person person;
	private AlphabetPanel ap;
	
	public HangmanGame()  {
		super("Hangman Game");
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// setup the panels
		person = new Person();
		person.setPreferredSize(new Dimension(650, 500));
		ap = new AlphabetPanel();
		ap.setPreferredSize(new Dimension(650, 50));
		
		super.getContentPane().setLayout(
				new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));

		super.getContentPane().add(ap);
		super.getContentPane().add(person);
		super.pack();
		super.setVisible(true);
	}

	public static void main(String[] args) {
		new HangmanGame();
	}

}
