import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class RandomString {

	private ArrayList<String> phrases;
	private Random random;
	
	public RandomString(String file) {
		// TODO initialize fields
	}
	
	// a method that returns a random string value from the file; 
	// this value shouldn’t be repeated until all guess phrases in 
	// the file have been used.
	public String next() {
		// TODO How to ensure that phrases don't repeat 
		// until all have been used
		int r = random.nextInt(phrases.size());
		return phrases.get(r);
	}

	public static void main(String[] args) {
		try {
			Scanner scan = new Scanner(new File("guess_phrases.txt"));
			ArrayList<String> puzzles = new ArrayList<String>();
			Random random = new Random();
			
			while (scan.hasNext()) {
				String line = scan.nextLine();
				//System.out.println(line);
				puzzles.add(line);
			}
			
			// random number from 0 thru pizzles.size() - 1 (inclusive)
			while (!puzzles.isEmpty()) {
				int r = random.nextInt(puzzles.size());
				System.out.println(puzzles.get(r));
				puzzles.remove(r);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		//System.out.println("I can continue");
	}

}
