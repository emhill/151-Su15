import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Picture extends JPanel {
	
	private BoxCar bcp;
	
	private static final int WIDTH = 500;
	private static final int HEIGHT = 500;
	
	public Picture() {
		bcp = new BoxCar(10, 100, 100, 300, 200);
	}
	
	public void paintComponent(Graphics page) {
		bcp.draw(page);
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Picture using Shapes");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		JPanel panel = new Picture();
		panel.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}


	
	
}
