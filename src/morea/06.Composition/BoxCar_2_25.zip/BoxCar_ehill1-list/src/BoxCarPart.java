import java.awt.Color;
import java.awt.Graphics;


public class BoxCarPart {
	private Circle wheel;
	private Rectangle box;
	
	public BoxCarPart(int x, int y, int width, int height) {
		wheel = new Circle();
		box = new Rectangle();
		wheel.setColor(Color.BLUE);
		box.setColor(Color.RED);
		setBounds(x, y, width, height);
	}
	
	public void setWheelColor(Color c) {
		wheel.setColor(c); // sets outline & fill color
	}
	
	public void setBoxColor(Color c) {
		box.setColor(c); // sets outline & fill color
	}
	
	public Color getWheelColor() { return wheel.getFillColor(); }
	public Color getBoxColor() { return box.getFillColor(); }

	public void setBounds(int x, int y, int width, int height) {
		box.setX(x);
		box.setY(y);
		box.setWidth(width);
		box.setHeight(height);
		
		wheel.setX(x + width / 2);
		wheel.setY(y + height);
		wheel.setRadius(width / 4);
	}
	
	public void draw(Graphics page) {
		box.draw(page);
		wheel.draw(page);
	}

}
