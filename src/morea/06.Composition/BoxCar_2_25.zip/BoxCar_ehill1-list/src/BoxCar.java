import java.awt.Graphics;
import java.util.ArrayList;


public class BoxCar {
	//private BoxCarPart bcp1, bcp2, bcp3;
	private ArrayList<BoxCarPart> bcps;
	
	public BoxCar(int num, int x, int y, int width, int height) {
		bcps = new ArrayList<BoxCarPart>();
		for (int index = 0; index < num; index++) {
//		int index = 0;
//		while (index < num) {
			BoxCarPart bcp = new BoxCarPart(x + index * width / num, 
										   y, 		   width / num, height);
			bcps.add(bcp);
			//index++; // index = index + 1
		}
	}
	
	public BoxCar(int x, int y, int width, int height) {
		this(3, x, y, width, height);
	}
	
	public void draw(Graphics page) {
		for (BoxCarPart bcp : bcps) {
			bcp.draw(page);
		}
	}

}
