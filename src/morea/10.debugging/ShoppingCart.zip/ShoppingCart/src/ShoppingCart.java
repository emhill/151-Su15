import java.text.NumberFormat;
import java.util.ArrayList;


public class ShoppingCart {
	private ArrayList<Item> items = new ArrayList<Item>();
	
	public double getTotal() {
		double total = 0;
		for (Item i : items)
			total += i.price;
		return total;
	}
	
	public Item getMaxPricedItem() {
		Item max = items.get(0);
		for (Item i : items) {
			if (i.price < max.price)
				max = i;
		}
		return max;
	}
	
	public void insertItem(Item i) {
		items.add(i);
	}
	
	public void printSummary() {
		System.out.println("\n------ SUMMARY ------");
		for (Item i : items) {
			System.out.println(i);
		}
	}
	
	public void remove(int index) {
		items.remove(index);
	}
	
	public void printInvoice() {
		System.out.println("\n------ INVOICE ------");
		double tot = 0;
		for (Item i : items)
			tot += i.price;
		
		for (Item i : items) {
			i.printDetails();
		}
		System.out.println("----------------------");
		System.out.println("Total: " + 
				NumberFormat.getCurrencyInstance().format(tot));
		System.out.println("Highest-priced item: " + getMaxPricedItem());
		System.out.println("----------------------");
	}
	
	public static void main(String[] args) {
		ShoppingCart checkout = new ShoppingCart();
		
		checkout.insertItem(new Item("Apples", 3.95, "2 lbs")); // produce
		checkout.insertItem(new Item("NY Yankees Tickets", 95, "behind home plate")); // entertainment
		checkout.insertItem(new Item("Leather boots", 145.50, "black")); // clothing
		checkout.insertItem(new Item("Bananas", .79, "organic")); // produce
		checkout.insertItem(new Item("Oranges", 1.49, "navel"));  // produce
		
		checkout.printSummary();
		checkout.printInvoice();
	}

}
