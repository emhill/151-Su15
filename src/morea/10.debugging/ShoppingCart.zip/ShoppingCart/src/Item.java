import java.text.NumberFormat;


public class Item {
	public String name;
	public double price;
	public String description;
	
	public Item(String n, double p, String d) {
		name = n;
		price = p;
		description = d;
	}
	
	public String toString() {
		return name + ", " + 
				NumberFormat.getCurrencyInstance().format(price);
	}
	
	public void printDetails() {
		System.out.println(name + " (" + description + ") " + price);
	}
}
