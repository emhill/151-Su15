/**
 * Iterative selection sort
 * For more information on sorting algorithms, try:
 * http://www.toves.org/books/java/ch20-sort/index.html
 * @author EmilyHill
 *
 */
public class IterativeSorter {
	
	private int[] sortedArray;
	private int[] array;
	
	public IterativeSorter() {
		array = new int[1];
	}
	
	public IterativeSorter(int[] a) {
		array = a;
	}

	public void setArray(int[] a) {
		array = a;
	}

	public int[] getSortedArray() {
		return sortedArray;
	}

	public int[] getOriginalArray() {
		return array;
	}
	
	public int[] sort() {
		sortedArray = array.clone();
	    for(int i = 0; i < sortedArray.length-1; i++) {
	        int min = i;
	        for(int j = i + 1; j < sortedArray.length; j++) {
	            if(sortedArray[j] < sortedArray[min]) min = j;
	        }
	        if (min != i) {
	        	int t = sortedArray[min];
	        	sortedArray[min] = sortedArray[i];
	        	sortedArray[i] = t;
	        }
	    }
	    return sortedArray;
	}
	
	public String toString() {
		return "Original: " + prettyPrint(getOriginalArray()) + "\n" +
			   "Sorted:   " + prettyPrint(getSortedArray());
	}
	
	private String prettyPrint(int[] a) {
		String s = "";
		for (int i : a)
			s += i + " ";
		return s;
	}
	
	public static void main(String[] args) {
		// Automate running, but not testing
		int[] array = {5, 67, 12, 20};
		IterativeSorter s = new IterativeSorter(array);
		s.sort();
		System.out.println(s); // uses Sorter.toString
	}

}
